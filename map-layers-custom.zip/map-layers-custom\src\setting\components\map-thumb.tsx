import { React, SessionManager, esri, getAppStore } from 'jimu-core'
import { Image } from 'jimu-ui'
import { PlaceholderMapFilled } from 'jimu-icons/filled/data/placeholder-map'

interface Props {
  mapItemId: string
  portUrl: string
}

interface States {
  mapThumbUrl: string
}

export default class MapThumb extends React.PureComponent<Props, States> {
  // Type-only declarations for Visual Studio under the EB 1.21 pnpm layout.
  // They restore the React instance members when VS fails to follow React's
  // inherited type declarations. `declare` fields emit no JavaScript.
  declare readonly props: Readonly<Props>
  declare state: Readonly<States>
  declare setState: (
    state: Partial<States> | ((previousState: Readonly<States>, props: Readonly<Props>) => Partial<States> | null),
    callback?: () => void
  ) => void

  unmount = false

  constructor (props) {
    super(props)

    this.state = {
      mapThumbUrl: null
    }
  }

  componentDidMount () {
    this.unmount = false
    this.setMapThumbUrl(this.props.mapItemId)
  }

  componentDidUpdate (prevProps: Props, prevState) {
    if (prevProps.mapItemId !== this.props.mapItemId) {
      this.setMapThumbUrl(this.props.mapItemId)
    }
  }

  setMapThumbUrl = (mapId: string): void => {
    if (!mapId) {
      this.setState({ mapThumbUrl: null })
    }

    if (!this.props.portUrl || this.props.portUrl === getAppStore().getState().portalUrl) {
      // if no portalUrl or same to config portalurl, use app config's portalUrl
      const portalUrl = getAppStore().getState().portalUrl
      const session = SessionManager.getInstance().getSessionByUrl(portalUrl)
      esri.restPortal.searchItems({
        q: `id:${mapId}`,
        authentication: SessionManager.getInstance().getSessionByUrl(portalUrl),
        portal: portalUrl + '/sharing/rest'
      }).then(items => {
        if (!this.unmount) {
          if (items.results[0]) {
            const tempThumbUrl = `${portalUrl}/sharing/rest/content/items/${items.results[0].id}/` +
            `info/${items.results[0].thumbnail}?token=${session?.token}`
            this.setState({ mapThumbUrl: tempThumbUrl })
          } else {
            this.setState({ mapThumbUrl: null })
          }
        }
      })
    } else {
      // use other portalUrl
      esri.restPortal.searchItems({
        q: `id:${mapId}`,
        portal: this.props.portUrl + '/sharing/rest'
      }).then(items => {
        if (!this.unmount) {
          if (items.results[0]) {
            const tempThumbUrl = `${this.props.portUrl}/sharing/rest/content/items/${items.results[0].id}/` +
            `info/${items.results[0].thumbnail}`
            this.setState({ mapThumbUrl: tempThumbUrl })
          } else {
            this.setState({ mapThumbUrl: null })
          }
        }
      })
    }
  }

  componentWillUnmount () {
    this.unmount = true
  }

  render () {
    if (this.state.mapThumbUrl) {
      return <Image src={this.state.mapThumbUrl} />
    } else {
      return <div style={{ backgroundColor: 'var(--ref-palette-neutral-300)', height: '100%' }} >
        <PlaceholderMapFilled color={'var(--ref-palette-neutral-600)'} size={'100%'} />
      </div>
    }
  }
}
